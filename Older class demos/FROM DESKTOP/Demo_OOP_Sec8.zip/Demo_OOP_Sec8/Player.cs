﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_OOP_Sec8
{
    /// <summary>
    /// This class represents a Player object
    /// Contains fields, 2 constructors, and a method.
    /// </summary>
    internal class Player
    {
        // --------------------------------------------------------------------
        // Fields (listed first)
        // Data that an object is made up of
        // All start with the "private" keyword
        // --------------------------------------------------------------------
        private string name;
        private int level;
        private string weapon;
        private string specialAbility;


        // --------------------------------------------------------------------
        // Constructor(s)
        // --------------------------------------------------------------------
        
        // Default constructor:
        // Assigns default data to each field of the class.
        // Written with no parameters
        public Player()
        {
            // Assign values to each and every field
            name = "Excalibur";
            level = 9000;
            weapon = "King Arthur";
            specialAbility = "become royalty";
        }

        // Parameterized Constructor
        // Has params, can pass data from Main into this instance of the class.
        // Allows us to receive custom data for each instance of this class
        public Player(string playerName, int playerLevel, string playerWeapon, string playerAbility)
        {
            // Assign values to each and every field
            name = playerName;
            level = playerLevel;
            weapon = playerWeapon;
            specialAbility = playerAbility;
        }


        // --------------------------------------------------------------------
        // Methods (listed last)
        // Methods in our classes should be labeled public
        // Do NOT include the static keyword
        // --------------------------------------------------------------------

        /// <summary>
        /// Prints information about this Player class
        /// </summary>
        public void Print()
        {
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Level: " + level);
            Console.WriteLine("Weapon: " + weapon);
            Console.WriteLine("Ability: " + specialAbility);
        }
    }
}
