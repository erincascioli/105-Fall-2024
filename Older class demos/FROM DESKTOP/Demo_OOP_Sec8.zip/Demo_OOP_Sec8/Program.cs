﻿
// Erin Cascioli
// 10/24/22
// Demo: Beginning OOP


namespace Demo_OOP_Sec8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ----------------------------------------------------------------
            // With OOP:
            // 4 Player objects encompass 16 variables (name for each, level for each, etc.)
            // ----------------------------------------------------------------

            // Instantiate Player objects
            // Syntax: Classname identifier = new Classname();
            // This uses the default constructor (which will be Excalibur)
            Player player1 = new Player(); 

            // These call the parameterized constructor to pass in custom data
            //   for each instance of the Player class
            Player player2 = new Player("Chinmay", 1, "grenade", "x-ray vision");
            Player player3 = new Player("Remi", 3, "trident", "super strength");
            Player player4 = new Player("Ariel", 4, "fork", "walk on human legs");

            // Call methods on the Player objects that we created
            player1.Print();
            Console.WriteLine();
            player2.Print();
            Console.WriteLine();
            player3.Print();
            Console.WriteLine();
            player4.Print();

            Console.WriteLine();


            /*
            // ----------------------------------------------------------------
            // Without OOP:
            // Separate set of variables to represent each item of the "category"
            // ----------------------------------------------------------------

            // First instance of a Player
            string name = "Excalibur";
            int level = 9000;
            string weapon = "King Arthur";
            string specialAbility = "become royalty when holding";

            // Second instance of a Player
            string name2 = "Player 2";
            int level2 = 1;
            string weapon2 = "weapon";
            string specialAbility2 = "ability";
            */
        }
    }
}