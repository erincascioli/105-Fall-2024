﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_OOP_Sec8
{
    /// <summary>
    /// This class represents a Player object
    /// Contains fields, 2 constructors, and a method.
    /// </summary>
    internal class Player
    {
        // --------------------------------------------------------------------
        // Fields (listed first)
        // Data that an object is made up of
        // All start with the "private" keyword
        // --------------------------------------------------------------------
        private string name;
        private int level;
        private string weapon;
        private string specialAbility;
        private Random rng;                 // DECLARE only


        // --------------------------------------------------------------------
        // Constructor(s)
        // --------------------------------------------------------------------
        
        // Default constructor:
        // Assigns default data to each field of the class.
        // Written with no parameters
        public Player()
        {
            // Assign values to each and every field
            name = "Excalibur";
            level = 9000;
            weapon = "King Arthur";
            specialAbility = "become royalty";
            rng = new Random();                 // INIT Random object
        }

        // Parameterized Constructor
        // Has params, can pass data from Main into this instance of the class.
        // Allows us to receive custom data for each instance of this class
        public Player(
            string playerName, 
            int playerLevel, 
            string playerWeapon, 
            string playerAbility)
        {
            // Assign values to each and every field
            name = playerName;
            level = playerLevel;
            weapon = playerWeapon;
            specialAbility = playerAbility;
            rng = new Random();                 // INIT Random object
        }

        /// <summary>
        /// Parameterized constructor allows us to pass in some data, while
        /// initializing other fields with default values.
        /// This version is used for a brand-new player, starting at level 1
        /// with no special ability.
        /// </summary>
        /// <param name="playerName">Name of the player</param>
        /// <param name="playerWeapon">Player's weapon</param>
        public Player(
            string playerName,
            string playerWeapon)
        {
            // Assign values to each and every field
            name = playerName;
            level = 1;
            weapon = playerWeapon;
            specialAbility = "none";
            rng = new Random();                 // INIT Random object
        }


        // --------------------------------------------------------------------
        // Methods (listed last)
        // Methods in our classes should be labeled public
        // Do NOT include the static keyword
        // --------------------------------------------------------------------

        /// <summary>
        /// Prints information about this Player class
        /// </summary>
        public void Print()
        {
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Level: " + level);
            Console.WriteLine("Weapon: " + weapon);
            Console.WriteLine("Ability: " + specialAbility);
        }

        /// <summary>
        /// Generates a random attack between 2 and 7 hit points.
        /// </summary>
        /// <returns>Hit points</returns>
        public int Attack()
        {
            // Attack values are random between 2, 3, 4, 5, 6, and 7.
            int randomHitPoints = rng.Next(2, 8);

            // Return the value!
            return randomHitPoints;

            // OR we could do this in one line:
            // return rng.Next(2, 8);
        }

        // "Stub out" a method that would receive damage to hurt a player

        /// <summary>
        /// Reduces a player's health by X amount.
        /// </summary>
        /// <param name="damage">Hit points to apply to player</param>
        public void TakeDamage(int damage)
        {
            // This method would harm a player somehow
            // health = health - damage;
        }
    }
}
