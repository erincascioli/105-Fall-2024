﻿
// Erin Cascioli
// 10/24/22
// Demo: Beginning OOP


namespace Demo_OOP_Sec8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Instantiate Player objects
            // Syntax: Classname identifier = new Classname();
            // This uses the default constructor (which will be Excalibur)
            Player player1 = new Player(); 

            // These call the parameterized constructor to pass in custom data
            //   for each instance of the Player class
            Player player2 = new Player("Chinmay", 1, "grenade", "x-ray vision");
            Player player3 = new Player("Remi", 3, "trident", "super strength");
            Player player4 = new Player("Ariel", 4, "fork", "walk on human legs");
            Player player5 = new Player("Andrew", "stick");
            Player player6 = new Player("Evan", 11, "pen", "none");

            // Call methods on the Player objects that we created
            player1.Print();
            Console.WriteLine();
            player2.Print();
            Console.WriteLine();
            player3.Print();
            Console.WriteLine();
            player4.Print();

            Console.WriteLine();

            // Attack other players!
            int attackFromP1 = player1.Attack();
            int attackFromP2 = player2.Attack();

            // This method is "stubbed out" and won't actually affect a 
            //   player's health, because Player objects don't have health.
            player2.TakeDamage(attackFromP1);
            player1.TakeDamage(attackFromP2);
        }
    }
}