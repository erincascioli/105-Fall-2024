﻿



namespace Demo_InheritanceLists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region List Class
            // ----------------------------------------------------------------
            // Using the List Class
            // ----------------------------------------------------------------
            /*
            // Declaration and initialization of Lists
            List<double> myList = new List<double>();
            List<string> myList2 = new List<string>();
            List<bool> myList3 = new List<bool>();

            // Inspect the list with properties
            //Console.WriteLine("List count: " + myList.Count);
            //Console.WriteLine("List capacity: " + myList.Capacity);

            // Adding to a list
            myList.Add(3.14);

            //Console.WriteLine("List count: " + myList.Count);
            //Console.WriteLine("List capacity: " + myList.Capacity);

            myList.Add(7.27);
            myList.Add(2.0);
            myList.Add(1);
            myList.Add(2);
            myList.Add(3);

            // Changing data in the list
            myList[5] = 1.2345;

            // Using properties and direct access to indices
            Console.WriteLine("The fourth thing in my list is " + myList[3]);
            Console.WriteLine("The size of the list is " + myList.Count);

            // Foreach loops will iterate through EVERY THING in the collection
            // Cannot modify the collection!  (Add, remove, change data)
            //   with foreach iteration
            // Syntax:
            // foreach(data type identifier in listname)
            foreach(double number in myList)
            {
                Console.WriteLine(number);
                //number = 999;
            }

            // For loops can be used, too. 
            // Can do anything you need within the for loop
            for(int i = 0; i < myList.Count; i+= 2)
            {
                Console.WriteLine(myList[i]);
                myList[i] = 999;
            }
            */
            #endregion

            // Inheritance!


        }
    }
}