﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_InheritanceLists
{
    /// <summary>
    /// Child classes inherit from a single parent class.
    /// </summary>
    internal class ChildClass : ParentClass
    {
        // Field that is unique to this child only
        private int[] myValues;

        // Chikd constructor initializes fields with values
        public ChildClass(int number, string word)
        {
            // Inits parent fields
            this.number = number;
            this.word = word;

            // Init child class fields
            this.myValues = new int[2];
            myValues[0] = 100;
            myValues[1] = 200;
        }
    }
}
