﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_InheritanceLists
{
    /// <summary>
    /// ParentClasses share ALL of their code with child classes
    /// They are considered a "base" class.
    /// </summary>
    internal class ParentClass
    {
        // Fields in the parent class are shared with the child class(es)
        protected string word;
        protected int number;

        // Properties are shared with the child class(es)
        public string Word
        {
            get { return word; }
        }

        // Parent constructor(s) should init fields of the parent class only
        public ParentClass()
        {
            // Init parent class only fields
            number = 10;
            word = "peanut";
        }

        public ParentClass(int number, string word)
        {
            // Init parent class only fields
            this.number = number;
            this.word = word;
        }

    }
}
