﻿
// Erin Cascioli
// 10/5/22
// Demo: NPC as a class


namespace Demo_NPC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Demonstrate:  Set up the first NPC in the "game"
            // Initialize an NPC
            NPC greg = new NPC();

            // Test window boundaries with off-screen translation values.
            greg.Translate(200, -4);

            // Change greg's color
            greg.ChangeColor(ConsoleColor.Green);

            // Draw the NPC in the window.
            greg.ShowNPC();

            // Demonstrate:  Set up more NPC's in the "game"
            // Mike
            NPC mike = new NPC();
            mike.Translate(4, 8);
            mike.ChangeColor(ConsoleColor.Magenta);
            mike.ShowNPC();

            // Gary
            NPC gary = new NPC();
            gary.Translate(16, 2);
            gary.ChangeColor(ConsoleColor.DarkYellow);
            gary.ShowNPC();

            // Gary
            NPC joshRevived = new NPC();
            joshRevived.Translate(16, 16);
            joshRevived.ChangeColor(ConsoleColor.Cyan);
            joshRevived.ShowNPC();

            // Prevent the ending text from taking over the console window!
            Console.ReadKey();
        }
    }
}