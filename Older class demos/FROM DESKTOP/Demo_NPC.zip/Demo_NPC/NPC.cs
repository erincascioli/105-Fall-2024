﻿using System;
using System.Collections.Generic;


namespace Demo_NPC
{
    /// <summary>
    /// Add a summary here 
    /// </summary>
    internal class NPC
    {
        // Order of class members:
        // 1. Fields
        // 2. Constructor(s)
        // 3. Method(s)

        // --------------------------------------------------------------------
        // Fields
        // --------------------------------------------------------------------
        private int positionX;
        private int positionY;
        private string color1;
        private ConsoleColor color2;
        private char symbol;

        // --------------------------------------------------------------------
        // Constructors
        // --------------------------------------------------------------------

        // Regular default constructor
        // Commented out to show how to use constructor chaining
        /*
        public NPC()
        {
            this.positionX = 0;
            this.positionY = 0;
            this.color1 = "blue";
            this.color2 = ConsoleColor.Blue;
            this.symbol = '&';
        }
        */

        /// <summary>
        /// Chained Constructor:
        /// Runs the parameterized constructor that accepts 5 values
        /// Sets up an object with default information.
        /// </summary>
        public NPC(): this(0, 0, "blue", ConsoleColor.Blue, '&')
        {
        }

        /// <summary>
        /// Parameterized Constructor:
        /// Sets up the NPC object with default values
        /// </summary>
        /// <param name="posX">Horizontal position within console window</param>
        /// <param name="posY">Vertical position within console window</param>
        /// <param name="color1">Text color (as a string)</param>
        /// <param name="color2">Text color (as a ConsoleColor)</param>
        /// <param name="symbol">Character used to display NPC</param>
        public NPC(int posX, int posY, string color1, ConsoleColor color2, char symbol)
        {
            this.positionX = posX;
            this.positionY = posY;
            this.color1 = color1;
            this.color2 = color2;
            this.symbol = symbol;
        }

        // --------------------------------------------------------------------
        // Methods
        // --------------------------------------------------------------------

        /// <summary>
        /// Draws this NPC to the console window.
        /// </summary>
        public void ShowNPC()
        {
            // Need to move the cursor to the position
            // Set the color
            // Draw the character there!
            Console.CursorLeft = positionX;
            Console.CursorTop = positionY;
            Console.ForegroundColor = color2;
            Console.Write(symbol);
        }

        /// <summary>
        /// Moves NPC by specified number of spaces along the horizontal or vertical axis.
        /// Caps movement to the window bounds.
        /// </summary>
        /// <param name="translationX">Number of spaces for NPC to move. 
        /// Left movement must be entered as a negative value.</param>
        /// <param name="translationY">Number of spaces for NPC to move.
        /// Upward movement must be entered as a negative value.</param>
        public void Translate(int translationX, int translationY)
        {
            // Movement of X
            positionX += translationX;
            positionY += translationY;

            // If NPC moves off-screen, cap his movement to the bounds
            //   of the console window.
            // Horizontal movement:
            if (positionX < 0)
            {
                positionX = 0;
            }
            else if (positionX > Console.WindowWidth)
            {
                positionX = Console.WindowWidth - 1;
            }

            // Vertical movement:
            if (positionY < 0)
            {
                positionY = 0;
            }
            else if (positionY > Console.WindowHeight)
            {
                positionY = Console.WindowHeight - 1;
            }
        }

        /// <summary>
        /// Changes the text color of this NPC
        /// </summary>
        /// <param name="color">String representing the color to change to</param>
        public void ChangeColor(string color)
        {
            // We have a nice "English-word" representation of the color, but...
            // How will this effect the character's color when drawn to the window?
            this.color1 = color;

            switch(color.ToLower())
            {
                case "blue":
                    color2 = ConsoleColor.Blue;
                    break;
                case "dark blue":
                    color2 = ConsoleColor.DarkBlue;
                    break;
                case "red":
                    color2 = ConsoleColor.Red;
                    break;
                case "dark red":
                    color2 = ConsoleColor.DarkRed;
                    break;
                // ...Et cetera ...
                default:
                    color2 = ConsoleColor.White;
                    break;
            }
        }

        /// <summary>
        /// Changes the text color of this NPC
        /// </summary>
        /// <param name="color">Console color option</param>
        public void ChangeColor(ConsoleColor color)
        {
            // Sets the ConsoleColor.
            this.color2 = color;
        }
    }
}
