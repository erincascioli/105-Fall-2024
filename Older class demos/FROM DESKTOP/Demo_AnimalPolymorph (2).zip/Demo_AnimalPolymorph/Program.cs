﻿namespace Demo_AnimalPolymorph
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(40, 20);
            Console.ForegroundColor = ConsoleColor.White;

            // Make a list of Animals
            List<Animal> myAnimals = new List<Animal>();

            // Create animals and print their data
            Rabbit roger = new Rabbit("Roger", 5, "alfalfa", 4);
            roger.Print();
            Console.WriteLine("The bunny can hop " + roger.NumberOfHops + " times");
            Cat dash = new Cat("Dash", 10, "crunchy treats");
            dash.Print();
            Dog bandit = new Dog("Bandit", 6, "coffee");
            bandit.Print();

            // Add 3 child types to a list of parent type.
            myAnimals.Add(roger);
            myAnimals.Add(dash);
            myAnimals.Add(bandit);

            // Call ToString method on the dog
            Console.WriteLine("Call ToString on the Dog object: ");
            Console.WriteLine(bandit);

            // Clear the console after pressing a key
            Console.WriteLine("Press 'ENTER' to continue.");
            Console.ReadLine();
            Console.Clear();

            // Display them all in the console
            foreach(Animal animalInstance in myAnimals)
            {
                // Every animal can be drawn to the console
                animalInstance.Draw();

                // Only downcast animals that are Rabbits
                // But check first if they are Rabbit objects!
                if(animalInstance is Rabbit)
                {
                    // Downcast is necessary when a child-cpecific implementation is needed.
                    // EITHER:
                    Rabbit rabbitReference = (Rabbit)animalInstance;
                    rabbitReference.SpecificMethod();
                    // OR:
                    ((Rabbit)animalInstance).SpecificMethod();
                }                
            }
            for(int i = 0; i < myAnimals.Count; i++)
            {
                myAnimals[i].Draw();
            }


            // Loop this for 10 iterations
            for (int i = 0; i < 10; i++)
            {
                // "Pause" the program
                // Move cursor to top left
                // And clear what was on the screen so we can see new positions of animals
                Console.CursorLeft = 0;
                Console.CursorTop = 0;

                Console.WriteLine("Press 'ENTER' to continue.");
                Console.ReadLine();
                Console.Clear();

                // Now they all use the same method name!
                // All animal classes overrode the parent class's Move method
                foreach (Animal animalInstance in myAnimals)
                {
                    animalInstance.Move();
                    animalInstance.Draw();
                }
            }
        }
    }
}