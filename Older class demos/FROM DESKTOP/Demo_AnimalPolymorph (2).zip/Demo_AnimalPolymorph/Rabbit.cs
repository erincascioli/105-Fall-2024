﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_AnimalPolymorph
{
    // Rabbit is a child class of Animal
    // Child classes receive all of the code from the shared parent class,
    //   including fields, properties, the parent constructor, and methods.
    // Child classes should not repeat any of the code from the parent class.
    // Children CAN define their own unique fields, properties, and methods
    //   if they have unique data or behaviors. 
    // Child class constructors will run AFTER the parent class's does.
    // Child class constructors must call the parent class's constructor 
    //   via the base keyword.

    internal class Rabbit : Animal
    {
        // Rabbit data
        private int numberOfHops;

        // Rabbit properties
        public int NumberOfHops
        {
            get { return numberOfHops; }
        }

        public Rabbit(string name, int age, string favoriteTreat, int numberOfHops)
            : base(name, age, favoriteTreat, 3, 11, ConsoleColor.White, "R")
        {
            // Child class handles unique field
            this.numberOfHops = numberOfHops;
        }

        /// <summary>
        /// Moves this rabbit to a new position in the console window
        /// X and Y positions are randomly generated and will remain
        /// in the bounds of the console window
        /// </summary>
        public override void Move()
        {
            // Choose a new spot on the console window
            RandomPosition();
        }

        public void SpecificMethod()
        {
            // Only exists here!
        }
    }
}
