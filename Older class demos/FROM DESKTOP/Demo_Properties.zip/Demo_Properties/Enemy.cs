﻿using System;
using System.Collections.Generic;

namespace Demo_Properties
{
    internal class Enemy
    {
        // --------------------------------------------------------------------
        // Fields
        // --------------------------------------------------------------------
        
        // Public vs. Private
        private int health;
        private string name;

        // --------------------------------------------------------------------
        // Properties
        // --------------------------------------------------------------------

        // Auto-property creates an "invisible" field with the same name, number,
        //   and uses basic gets and sets to access that data. 
        // NOT ALLOWED in 105!!!
        public double Number { get; set; }


        // *****************************************************************
        // Properties are C#'s way of interacting with private data        *
        // Properties must have a return type                              *
        // Gets must return data of that type                              *
        // Sets must use the keyword "value" as the one allotted parameter *
        // *****************************************************************

        /// <summary>
        /// Health property for this Enemy class.
        /// Health can only be set to a new value if the value is less than the current health value.
        /// </summary>
        public int Health
        {
            get
            {
                return health;
            }
            set
            {
                if(value < health)
                {
                    health = value;
                }
            }
        }

        /// <summary>
        /// Property for the Name field.  
        /// Only allows name to be set if the new name is 4 letters or longer.
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                // Only allow names 4 letters or longer to be set as the name
                if (value.Length > 3)
                {
                    name = value;
                }
            }
        }
        
        // --------------------------------------------------------------------
        // Constructor
        // --------------------------------------------------------------------

        /// <summary>
        /// Default constructor
        /// Initializes every Enemy with the same data
        /// </summary>
        public Enemy()
        {
            health = 100;
            name = "Enemy";
        }

        /// <summary>
        /// Paramaterized constructor
        /// Allows for custom information for each Enemy
        /// </summary>
        /// <param name="health">Health, out of 100 possible points</param>
        /// <param name="name">Name of the Enemy</param>
        public Enemy(int health, string name, int number)
        {
            // Cap health at 100
            this.health = health;
            if(this.health > 100)
            {
                this.health = 100;
            }

            // No limits on name
            this.name = name;

            // Everywhere the "backing-field" for an auto-property is used, the property
            //   is the way of interacting with that invisible field
            this.Number = number;
        }

        // --------------------------------------------------------------------
        // Methods
        // --------------------------------------------------------------------

        /// <summary>
        /// Prints Enemy information, including the name and health.
        /// </summary>
        public void PrintEnemyInformation()
        {
            Console.WriteLine($"Name: {name}");
            Console.WriteLine($"Health: {health}");
        }

        /// <summary>
        /// Applies damage to an Enemy
        /// </summary>
        /// <param name="damage">Amount of hit points</param>
        public void TakeDamage(int damage)
        {
            // Only allow positive damage otherwise negative
            //   damage would heal character
            if(damage > 0)
            {
                health -= damage;
            }
        }
    }
}
