﻿// Erin Cascioli
// 10/14/22
// Demo: Properties and Encapsulation

namespace Demo_Properties
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create an Enemy with default and parameterized constructors
            Enemy bob = new Enemy();                    // Default
            Enemy tom = new Enemy(100, "Tom", 2);       // Parameterized
            Enemy pam = new Enemy(200, "Pam", 5);       // Parameterized

            // ERRORS:
            // Can't do this with private data!
            // Private data is inaccessible to the Program class.
            //bob.name = "Bob";
            //string enemyName = bob.name;

            // Use properties to interact with the class data
            string name = bob.Name;             // GET
            bob.Name = "Bo";                    // SET - limited, won't change
            bob.Name = "Bobberino";             // SET - limited, WILL change!

            int enemyHealth = bob.Health;       // GET
            Console.WriteLine(bob.Health);      // GET

            bob.Health = 120;                   // SET - limited, won't change!

            // Auto property usage calls the get and set
            tom.Number = 23;
            Console.WriteLine(pam.Number);
        }
    }
}