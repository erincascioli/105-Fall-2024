﻿
// Erin Cascioli
// 10/24/22
// Demo: Beginning OOP



namespace Demo_OOP_Sec5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ----------------------------------------------------------------
            // With OOP:
            // ----------------------------------------------------------------

            // Instantiate (create an instance of) a Player object
            // Classname identifier = new Classname();
            Player firstPlayer = new Player("Matthew", 2, "glaive", "Laser eyes");
            Player secondPlayer = new Player("Andrew", 1, "my hand", "Breathe fire");
            Console.WriteLine();

            // Can call methods of the Player class on instances of the Player class
            firstPlayer.Print();
            secondPlayer.Print();

            // ----------------------------------------------------------------
            // Without OOP:
            // We need LOTS of separate variables to represent the Players in our game
            // ----------------------------------------------------------------

            /*
            // Represent the first Player object
            string name1 = "Nikki";
            int level1 = 3;
            string weapon1 = "flail";
            string specialAbility1 = "Burning hands";

            // Represent the second Player object
            string name2 = "Matthew";
            int level2 = 2;
            string weapon2 = "glaive";
            string specialAbility2 = "Laser eyes";

            // Represent the third Player object
            string name3 = "Andrew";
            int level3 = 1;
            string weapon3 = "my hand";
            string specialAbility3 = "Breathe fire";
            */

        }
    }
}