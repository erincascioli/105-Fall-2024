﻿
// Erin Cascioli
// 9/28/22
// Demo: List Class


using System.Collections.Generic;   //ADD THIS EVERY TIME!!!

namespace Demo_Lists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create and initialize a list ("Instantiate")
            List<string> daysOfTheWeek = new List<string>();

            // Check out the capacity and count of the list
            Console.WriteLine("List capacity: " + daysOfTheWeek.Capacity);
            Console.WriteLine("List count: " + daysOfTheWeek.Count);

            // Add data to the list
            daysOfTheWeek.Add("Monday");
            daysOfTheWeek.Add("Tuesday");
            daysOfTheWeek.Add("Wednesday");
            daysOfTheWeek.Add("Thursday");
            daysOfTheWeek.Add("Friday");
            daysOfTheWeek.Add("Saturday");
            daysOfTheWeek.Add("Sunday");
            daysOfTheWeek.Add("Pretendday");
            daysOfTheWeek.Add("Anotherday");

            // Check out the capacity and count of the list again...
            // The size has increased to 9, and the capacity is 16
            //   as the array resizes by doubling
            Console.WriteLine("List capacity: " + daysOfTheWeek.Capacity);
            Console.WriteLine("List count: " + daysOfTheWeek.Count);

            // Insert into the list twice
            daysOfTheWeek.Insert(0, "Sunday");
            daysOfTheWeek.Insert(2, "Sunday");

            // Iterate through list with for, printing each data
            Console.WriteLine("The list contains: ");
            for (int i = 0; i < daysOfTheWeek.Count; i++)
            {
                Console.WriteLine("  -" + daysOfTheWeek[i]);
            }

            // Check out the capacity and count of the list again...
            // The size has increased to 9, and the capacity is 16
            //   as the adray resizes by doubling
            Console.WriteLine();
            Console.WriteLine("List capacity: " + daysOfTheWeek.Capacity);
            Console.WriteLine("List count: " + daysOfTheWeek.Count);

            // Remove data from the list
            daysOfTheWeek.Remove("Sunday");     // <-- This removes the 1st instance
            //daysOfTheWeek.RemoveAt(15);       // <-- Will crash, invalid index.

            // Search for an item
            bool fridayInList = daysOfTheWeek.Contains("Friday");
            if(fridayInList)
            {
                Console.WriteLine("Friday is there! ");
            }
            else
            {
                Console.WriteLine("Friday is not there.");
            }

            // Get the index of an item
            // Will be -1 if index isnt there
            int index = daysOfTheWeek.IndexOf("Friday");
            index = daysOfTheWeek.IndexOf("More day");
        }
    }
}