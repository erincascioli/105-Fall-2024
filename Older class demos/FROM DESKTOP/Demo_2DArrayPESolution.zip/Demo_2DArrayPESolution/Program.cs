﻿
// Erin Cascioli
// 12/2/22
// Demo: Completed 2D PE solution. 
// Feel free to use to study from. 


namespace Demo_2DArrayPESolution
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Using a seed means the values will always be the same
            //   which is REALLY nice for testing specific data!
            // Once I know the program works the way I need it to,
            //   I can remove the seed and it will be random again.

            // Initialize Random object
            Random myRandom = new Random(5);        // Seed is 5. Remove when done.

            // Init a 2D array of 2 x 4 elements with random values
            int[,] integerArray = new int[2, 4];
            Fill2DArray(integerArray, myRandom, 0, 100);

            // Print values in the array
            Print2DArray(integerArray);

            // ----------------------------------------------------------------
            // Not part of the exercise -
            //   added here to show how the method can be used for differently sized arrays.

            // Let's try another size array!
            Console.WriteLine("\n Trying a different array...");

            // Init a 2D array of 2 x 4 elements with random values
            int[,] integerArray2 = new int[6,6];
            Fill2DArray(integerArray2, myRandom, 0, 100);

            // Print values in the array
            Print2DArray(integerArray2);
            // ----------------------------------------------------------------
        }

        /// <summary>
        /// Fills a 2-dimensional (multidimensional) array with random values in a specified range.
        /// </summary>
        /// <param name="array">2D array of integers</param>
        /// <param name="generator">Random reference</param>
        /// <param name="low">Lowest random value, inclusive.</param>
        /// <param name="high">Highest random value, inclusive.</param>
        public static void Fill2DArray(
            int[,] array, 
            Random generator, 
            int low, 
            int high)
        {
            // Find the size of the incoming array
            int numRows = array.GetLength(0);
            int numCols = array.GetLength(1);

            // Fill the 2D array with random values
            for (int row = 0; row < numRows; row++)
            {
                for (int col = 0; col < numCols; col++)
                {
                    array[row, col] = generator.Next(low, high + 1);
                }
            }
        }

        /// <summary>
        /// Display a 2D array of integers in the console window.
        /// </summary>
        /// <param name="array">2D array of integers</param>
        public static void Print2DArray(int[,] array)
        {
            // Find the size of the incoming array
            int numRows = array.GetLength(0);
            int numCols = array.GetLength(1);

            // Print the column before iterating through array
            // Looped so it can be used for any size array.
            for (int i = 1; i <= numCols; i++) 
            {
                Console.Write("\tCol {0}:", i);
            }
            Console.WriteLine();

            // Iterate through the values, printing each one in a column.
            for (int row = 0; row < numRows; row++)
            {
                // The row number should be printed before the row's data
                Console.Write("Row {0}:", (row + 1));

                // Write each element to the console
                for (int col = 0; col < numCols; col++)
                {
                    Console.Write("\t" + array[row,col]);
                }

                // Get ready for the next line of data.
                Console.WriteLine();
            }
        }
    }
}