﻿
// Erin Cascioli
// 10/14/22
// Demo: Arrays and Methods with some Array Algorithms 

namespace ArrayAlgorithms_CompletedDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ----------------------------------------------------------------
            // Create some literal arrays
            // You must know ALL of the data before creating a literal array
            // ----------------------------------------------------------------
            int[] numbers = { 2, 4, 6, 8, 10 };
            string[] words = { "Hi", "there", "everyone" };
            double[] sortedValues = { 2.4, 6.8, 10.0, 14.8 };
            double[] unsortedValues = { 2.0, 5.6, 1.3, 19.2 };


            // ----------------------------------------------------------------
            // The FillArray methods are used to receive an array as a parameter
            //   and CHANGE THAT ARRAY to contain initial starting data
            // ----------------------------------------------------------------
            // Declare and Init - Do NOT enter data
            // Then we can call the FillArray methods!
            // It will change the array that's passed as param
            int[] numbers2 = new int[5];
            FillArray(numbers2, 74);
            string[] words2 = new string[3];
            FillArray(words2, "initial data");

            // ----------------------------------------------------------------
            // Call ArrayOfMultiples
            // This RETURNS A NEW ARRAY of integers
            // ----------------------------------------------------------------
            // Declare the array
            // Initialize it with the returned array from the method
            int[] myNewArray = ArrayOfMultiples(7, 5);
            int[] myNewArray2 = ArrayOfMultiples(3, 10);
            int[] myNewArray3 = ArrayOfMultiples(10, 5);

            // ----------------------------------------------------------------
            // Call IsSorted
            // This returns a BOOLEAN of whether the array is sorted or not.
            // ----------------------------------------------------------------
            // Declare the array
            // Initialize it with the returned array from the method
            bool arrayIsSorted = IsSorted(sortedValues);
            Console.WriteLine("Is the array sorted? " + arrayIsSorted);

            arrayIsSorted = IsSorted(unsortedValues);
            Console.WriteLine("Is the array sorted? " + arrayIsSorted);

            // ----------------------------------------------------------------
            // Call HowManyValues
            // This returns the number of vowels in a string
            // ----------------------------------------------------------------
            string myString1 = "cat";
            int numberVowels = HowManyVowels(myString1);
            Console.WriteLine($"The string \"{myString1}\" has {numberVowels} vowels.");

            string myString2 = "celebration";
            numberVowels = HowManyVowels(myString2);
            Console.WriteLine($"The string \"{myString2}\" has {numberVowels} vowels.");

        } // End of Main - Write methods AFTER this


        /// <summary>
        /// Fills an INTEGER array with a starting value
        /// </summary>
        /// <param name="array"></param>
        /// <param name="startingValue"></param>
        public static void FillArray(int[] array, int startingValue)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = startingValue;
            }
        }


        /// <summary>
        /// Fills a STRING array with a starting value
        /// </summary>
        /// <param name="array"></param>
        /// <param name="startingValue"></param>
        public static void FillArray(string[] array, string startingValue)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = startingValue;
            }
        }


        /// <summary>
        /// Creates an array of a value factored a specified number of times.
        /// </summary>
        /// <param name="startingNumber">Value to be factored</param>
        /// <param name="length">How many values the array should contain</param>
        /// <returns>A new integer array containing those values</returns>
        public static int[] ArrayOfMultiples(int startingNumber, int length)
        {
            // Return a NEW array that has the starting number factored
            //   for x length

            // Declare and init new int array
            int[] factoredArray = new int[length];

            // Iterate for the number of elements
            for(int i = 0; i < length; i++)
            {
                // Assign a factor of startingNumber to the array
                factoredArray[i] = startingNumber * (i + 1);
            }

            return factoredArray;
        }


        /// <summary>
        /// Counts the number of vowels in a word. Vowels are a, e, i, o or u.
        /// </summary>
        /// <param name="word">String to count vowels for</param>
        /// <returns>Number of vowels in the string</returns>
        public static int HowManyVowels(string word)
        {
            // Start with an "accumulator" variable
            int numberVowels = 0;

            // Convert to lowercase to check for vowels
            // Doing this eliminates the need to check for both upper & lowercase vowels
            string wordLowerCase = word.ToLower();

            // Iterate through that lowercase version of the string
            for(int i = 0; i < wordLowerCase.Length; i++)
            {
                // Found a vowel!  Count it up!
                if (wordLowerCase[i] == 'a' ||
                    wordLowerCase[i] == 'e' ||
                    wordLowerCase[i] == 'i' ||
                    wordLowerCase[i] == 'o' ||
                    wordLowerCase[i] == 'u')
                {
                    numberVowels++;
                }
            }

            return numberVowels;
        }

        /// <summary>
        /// Determines if an array is already sorted
        /// </summary>
        /// <param name="array">Array of doubles</param>
        /// <returns>True if sorted, false if unsorted.</returns>
        public static bool IsSorted(double[] array)
        {
            // Iterate through the array, checking that each element is less than the element after it.
            // Start with index 0 but end with the second-to-last index
            // Why? Because we need to check index i against index (i + 1) and the program
            //   will crash if i is the last index and we attempt to access index (i + 1)
            for(int i = 0; i < array.Length - 1; i++)
            {
                // Once we find that an element is larger than its neighbor,
                //   the array is no longer sorted.
                if (array[i] > array[i + 1])
                {
                    return false;
                }
            }

            return true;
        }

    }// End of Program - write methods BEFORE this
}